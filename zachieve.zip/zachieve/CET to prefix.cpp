#include <iostream>
#include <stack>
#include <string>

using namespace std;

// TreeNode structure
struct TreeNode {
    char data;
    TreeNode *left, *right;

    TreeNode(char val) {
        data = val;
        left = right = nullptr;
    }
};

// Function to check if a character is an operator
bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Function to construct expression tree from prefix expression
TreeNode* constructTree(const string& prefix) {
    stack<TreeNode*> s;

    // Traverse the prefix expression in reverse order
    for (int i = prefix.length() - 1; i >= 0; i--) {
        char c = prefix[i];

        // If the character is an operator
        if (isOperator(c)) {
            TreeNode* node = new TreeNode(c);
            // Pop two nodes from the stack for the left and right children
            node->left = s.top(); s.pop();
            node->right = s.top(); s.pop();
            // Push the new node back onto the stack
            s.push(node);
        } else { // If the character is an operand
            s.push(new TreeNode(c));
        }
    }
    
    // The last element in the stack is the root of the expression tree
    return s.top();
}

// Function for inorder traversal of the tree
void inorder(TreeNode* root) {
    if (root) {
        inorder(root->left);
        cout << root->data << " ";
        inorder(root->right);
    }
}

int main() {
    string prefixExpression;
    
    cout << "Enter a prefix expression: ";
    cin >> prefixExpression;

    TreeNode* root = constructTree(prefixExpression);

    cout << "Inorder traversal of the constructed expression tree: ";
    inorder(root);
    
    return 0;
}