#include <iostream>
#include <climits>
using namespace std;

const int V = 6; // Number of vertices in the graph

// Function to find the vertex with the minimum key value
int minKey(int key[], bool mstSet[]) {
    int min = INT_MAX, min_index;
    for (int v = 0; v < V; v++) {
        if (!mstSet[v] && key[v] < min) {
            min = key[v];
            min_index = v;
        }
    }
    return min_index;
}

// Function to implement Prim's algorithm
void findMST(int cost[V][V]) {
    int parent[V], key[V];
    bool mstSet[V] = {false}; 

    // Initialize all keys as infinite and parent[] as -1
    fill(key, key + V, INT_MAX);
    key[0] = 0;  // Start with the first vertex

    for (int count = 0; count < V - 1; count++) {
        int u = minKey(key, mstSet); // Find the vertex with the minimum key
        mstSet[u] = true; // Add the vertex to MST

        for (int v = 0; v < V; v++) {
            // Update the key value and parent of the adjacent vertices
            if (cost[u][v] && !mstSet[v] && cost[u][v] < key[v]) {
                parent[v] = u;
                key[v] = cost[u][v];
            }
        }
    }

    // Print the MST
    cout << "Edge \tWeight\n";
    for (int i = 1; i < V; i++) {
        cout << parent[i] << " - " << i << "\t" << cost[i][parent[i]] << " \n";
    }
}

int main() {
    int cost[V][V] = { {0, 2, 0, 6, 0, 0},
                       {2, 0, 3, 8, 5, 0},
                       {0, 3, 0, 0, 7, 0},
                       {6, 8, 0, 0, 9, 0},
                       {0, 5, 7, 9, 0, 4},
                       {0, 0, 0, 0, 4, 0} };

    findMST(cost); // Call function to find MST
    return 0;
}
