#include <iostream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

typedef pair<int, int> Edge;

void dijkstra(int source, const vector<vector<Edge>>& graph, vector<int>& distances) {
    priority_queue<Edge, vector<Edge>, greater<Edge>> pq;
    distances.assign(graph.size(), numeric_limits<int>::max());
    distances[source] = 0;
    pq.push({0, source});

    while (!pq.empty()) {
        auto [current_distance, current_vertex] = pq.top(); pq.pop();
        if (current_distance > distances[current_vertex]) continue;

        for (auto& [neighbor_vertex, weight] : graph[current_vertex]) {
            int new_distance = current_distance + weight;
            if (new_distance < distances[neighbor_vertex]) {
                distances[neighbor_vertex] = new_distance;
                pq.push({new_distance, neighbor_vertex});
            }
        }
    }
}

int main() {
    int vertices, edges;
    cin >> vertices >> edges;
    vector<vector<Edge>> graph(vertices);

    for (int i = 0; i < edges; ++i) {
        int u, v, w;
        cin >> u >> v >> w;
        graph[u].emplace_back(v, w);
        graph[v].emplace_back(u, w);
    }

    int source;
    cin >> source;

    vector<int> distances;
    dijkstra(source, graph, distances);

    for (int i = 0; i < vertices; ++i)
        cout << "Vertex " << i << ": " << (distances[i] == numeric_limits<int>::max() ? "Unreachable" : to_string(distances[i])) << "\n";

    return 0;
}
