#include <iostream>
using namespace std;

// Node structure for linked list
struct Node {
    int processID; // Process ID
    Node* next; // Pointer to the next node
};

// Queue class using linked list
class Queue {
private:
    Node* front; // Pointer to the front of the queue
    Node* rear; // Pointer to the rear of the queue

public:
    Queue() {
        front = nullptr; // Initialize front to null
        rear = nullptr; // Initialize rear to null
    }

    // Function to check if the queue is empty
    bool isEmpty() {
        return front == nullptr;
    }

    // Function to add a process to the queue (enqueue)
    void insert(int processID) {
        Node* newNode = new Node(); // Create a new node
        newNode->processID = processID; // Set process ID
        newNode->next = nullptr; // New node will be at the end, so next is null

        if (isEmpty()) {
            front = rear = newNode; // If queue is empty, both front and rear point to new node
        } else {
            rear->next = newNode; // Link the old rear to the new node
            rear = newNode; // Update rear to point to the new node
        }
        cout << "Process " << processID << " inserted into queue." << endl;
    }

    // Function to remove a process from the queue (dequeue)
    int deleteProcess() {
        if (isEmpty()) {
            cout << "Queue is empty! Cannot delete." << endl;
            return -1; // Indicate empty queue
        }
        int deletedProcessID = front->processID; // Get process ID from front node
        Node* temp = front; // Store current front node for deletion
        front = front->next; // Move front pointer to the next node

        if (front == nullptr) { // If queue becomes empty after deletion
            rear = nullptr; // Update rear as well
        }
        
        delete temp; // Free memory of old front node
        cout << "Process " << deletedProcessID << " deleted from queue." << endl;
        return deletedProcessID; // Return deleted process ID
    }

    // Function to display all processes in the queue
    void display() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return;
        }
        Node* temp = front;
        cout << "Processes in Queue: ";
        while (temp != nullptr) {
            cout << temp->processID << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

// Main function to demonstrate job scheduling in FCFS manner
int main() {
    Queue queue;
    
    int choice, processID;

    do {
        cout << "\n1. Insert Process\n2. Delete Process\n3. Display Queue\n4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Process ID to insert: ";
                cin >> processID;
                queue.insert(processID);
                break;

            case 2:
                queue.deleteProcess();
                break;

            case 3:
                queue.display();
                break;

            case 4:
                cout << "Exiting..." << endl;
                break;

            default:
                cout << "Invalid choice! Please try again." << endl;
                break;
        }
    } while (choice != 4);

    return 0;
}