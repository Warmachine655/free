#include <iostream>
using namespace std;

// Structure for a tree node
struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int value) : data(value), left(nullptr), right(nullptr) {}
};

// Function to insert a new node into the BST
Node* insert(Node* root, int value) {
    if (!root) return new Node(value);
    if (value < root->data)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);
    return root;
}

// Function for in-order traversal
void displayInOrder(Node* root) {
    if (root) {
        displayInOrder(root->left);
        cout << root->data << " ";
        displayInOrder(root->right);
    }
}

// Function for pre-order traversal
void displayPreOrder(Node* root) {
    if (root) {
        cout << root->data << " ";
        displayPreOrder(root->left);
        displayPreOrder(root->right);
    }
}

// Function for post-order traversal
void displayPostOrder(Node* root) {
    if (root) {
        displayPostOrder(root->left);
        displayPostOrder(root->right);
        cout << root->data << " ";
    }
}

int main() {
    Node* root = nullptr;

    // Example values to insert into the BST
    int values[] = {50, 30, 70, 20, 40, 60, 80};

    // Inserting values into the BST
    for (int value : values) {
        root = insert(root, value);
    }

    // Displaying the tree in different orders
    cout << "Pre-order Traversal: ";
    displayPreOrder(root);
    
    cout << "\nIn-order Traversal: ";
    displayInOrder(root);

    cout << "\nPost-order Traversal: ";
    displayPostOrder(root);

    return 0;
}