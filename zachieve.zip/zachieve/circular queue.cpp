#include <iostream>
using namespace std;

class CircularQueue {
private:
    int front, rear, size;
    int *queue;
    int capacity;

public:
    // Constructor to initialize the queue
    CircularQueue(int cap) {
        capacity = cap;
        front = rear = -1;
        size = 0;
        queue = new int[capacity];
    }

    // Destructor to free allocated memory
    ~CircularQueue() {
        delete[] queue;
    }

    // Function to check if the queue is full
    bool isFull() {
        return (size == capacity);
    }

    // Function to check if the queue is empty
    bool isEmpty() {
        return (size == 0);
    }

    // Function to add an element to the queue
    void enqueue(int value) {
        if (isFull()) {
            cout << "Queue is full. Cannot enqueue " << value << endl;
            return;
        }
        
        // If this is the first element being enqueued
        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % capacity; // Circular increment
        }
        
        queue[rear] = value;
        size++;
        cout << "Enqueued: " << value << endl;
    }

    // Function to remove an element from the queue
    int dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty. Cannot dequeue." << endl;
            return -1; // Indicating that the queue is empty
        }
        
        int value = queue[front];
        
        if (front == rear) { // Queue has only one element
            front = rear = -1; // Resetting the queue
        } else {
            front = (front + 1) % capacity; // Circular increment
        }
        
        size--;
        cout << "Dequeued: " << value << endl;
        return value;
    }

    // Function to display the elements of the queue
    void display() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return;
        }

        cout << "Queue elements: ";
        
        for (int i = 0; i < size; i++) {
            cout << queue[(front + i) % capacity] << " ";
        }
        
        cout << endl;
    }
};

int main() {
    CircularQueue cq(5); // Creating a circular queue of capacity 5

    cq.enqueue(10);
    cq.enqueue(20);
    cq.enqueue(30);
    
    cq.display();

    cq.dequeue();
    
    cq.display();

    cq.enqueue(40);
    cq.enqueue(50);
    
    cq.display();

    cq.enqueue(60); // This should show that the queue is full

    return 0;
}