#include <iostream>
using namespace std;

// Node structure for linked list
struct Node {
    int data;
    Node* next;
};

// Stack class using linked list
class Stack {
private:
    Node* top; // Pointer to the top of the stack

public:
    Stack() { top = nullptr; } // Constructor initializes top to null

    // Push operation
    void push(int value) {
        Node* newNode = new Node(); // Create a new node
        newNode->data = value; // Set node data
        newNode->next = top; // Link new node to the previous top
        top = newNode; // Update top to the new node
    }

    // Pop operation (simplified)
    int pop() {
        if (top == nullptr) {
            cout << "Stack is empty!" << endl;
            return -1; // Indicate stack is empty
        }
        Node* temp = top; // Store current top node
        int poppedValue = temp->data; // Get value to return
        top = top->next; // Move top to the next node
        delete temp; // Free memory of old top
        return poppedValue; // Return popped value
    }

    // Display stack elements
    void display() {
        if (top == nullptr) {
            cout << "Stack is empty" << endl;
            return;
        }
        Node* temp = top;
        cout << "Stack elements: ";
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

// Main function to demonstrate stack operations
int main() {
    Stack stack;

    stack.push(10);
    stack.push(20);
    stack.push(30);
    
    stack.display();

    cout << "Popped: " << stack.pop() << endl;
    
    stack.display();

    return 0;
}
