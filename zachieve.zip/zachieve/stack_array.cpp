#include <iostream>
using namespace std;

class stack{

    public:
    
    int ary[5];
    int top;

    stack()
    {
        top=-1;
    }

    void push(int x)
    {
        if(top==4)
        {
            cout<<"stack is overflow"<< endl;
            return;
        }

        ary[++top]=x;
    }

    void pop()
    {
        if(top==-1)
        {
            cout<<"stack is underflow"<< endl;
            return;
        }
        top--;
    }

    void display()
    {
      if(top==-1)
        {
            cout<<"stack is overflow"<< endl;
            return;
        }
        for(int i=0; i<=top; i++)
        {
        cout<<ary[i]<<endl;  
        }
    }
};

int main()
{
    stack s1;
    int choice , x;

    while (true)
    {
        cout << "1. Push" << endl;
        cout << "2. Pop" << endl;
        cout << "3. Display" << endl;
        cout << "4. End" << endl;
        cin >> choice; 

        switch (choice) 
        {
            case 1:
                cout << "Enter the element: ";
                cin >> x; // Use '>>' for input
                s1.push(x); // Add the element to the stack
                break;
            case 2:
                s1.pop(); // Remove the top element
                break;
            case 3:
                s1.display(); // Display the stack
                break;
            case 4:
                return 0; // End the program
            default:
                cout << "Invalid choice" << endl;
        }
    }
    return 0;
}