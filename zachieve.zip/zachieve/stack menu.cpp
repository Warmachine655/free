#include <iostream>   
using namespace std;

class Stack {
public:
    int stack[6]; // Define the stack array
    int top;

    Stack() { // Constructor for the Stack class
        top = -1; // Initialize top to -1
    }



    void push(int x) {
        if (top == 5) {
            cout << "Stack is overflowing" << endl; // Check for overflow
            return;
        }
        stack[++top] = x; // Store the value in the stack
    }
    
    void pop() {
        if (top == -1) {
            cout << "Stack is empty" << endl; // Check if stack is empty
            return;
        }
        top--; // Remove the top element
    }

    void display() {
        if (top == -1) {
            cout << "Stack is empty" << endl; // Check if stack is empty
            return;
        }
        for (int i = 0; i <= top; i++) {
            cout << stack[i] << endl; // Display each element in the stack
        }
    }
};

int main() {
    Stack s1; // Create an object of Stack
    int choice, x;

    while (true)
     {
        cout << "1. Push" << endl;
        cout << "2. Pop" << endl;
        cout << "3. Display" << endl;
        cout << "4. End" << endl;
        cin >> choice; // Use '>>' for input

        switch (choice) 
        {
            case 1:
                cout << "Enter the element: ";
                cin >> x; // Use '>>' for input
                s1.push(x); // Add the element to the stack
                break;
            case 2:
                s1.pop(); // Remove the top element
                break;
            case 3:
                s1.display(); // Display the stack
                break;
            case 4:
                return 0; // End the program
            default:
                cout << "Invalid choice" << endl; // Handle invalid input
        }
    }

    return 0; // Return statement for main
}
