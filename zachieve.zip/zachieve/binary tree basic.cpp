#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left = nullptr;  // Default initialization
    Node* right = nullptr; // Default initialization

    Node(int value) : data(value) {}  // Only initialize 'data'
};

// Function to insert a node
Node* insert(Node* root, int value) {
    if (!root) return new Node(value);
    if (value < root->data)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);
    return root;
}

// Function to display the tree (in-order traversal)
void display(Node* root) {
    if (root) {
        display(root->left);
        cout << root->data << " ";
        display(root->right);
    }
}

// Function to display leaf nodes
void displayLeafNodes(Node* root) {
    if (root) {
        if (!root->left && !root->right)
            cout << root->data << " ";
        else {
            displayLeafNodes(root->left);
            displayLeafNodes(root->right);
        }
    }
}

int main() {
    Node* root = nullptr;
    // Insert values into the BST
    root = insert(root, 10);
    insert(root, 5);
    insert(root, 15);
    insert(root, 3);
    insert(root, 7);

    // Display in-order and leaf nodes
    cout << "In-order Display: ";
    display(root);
    cout << "\nLeaf Nodes: ";
    displayLeafNodes(root);

    return 0;
}
