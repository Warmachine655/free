#include <iostream>
using namespace std;

// Structure for a tree node
struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int value) : data(value), left(nullptr), right(nullptr) {}
};

// Function to insert a new node in the binary tree
Node* insert(Node* root, int value) {
    if (!root) return new Node(value);
    if (value < root->data)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);
    return root;
}

// Function for in-order traversal
void displayInOrder(Node* root) {
    if (root) {
        displayInOrder(root->left);
        cout << root->data << " ";
        displayInOrder(root->right);
    }
}

// Function for pre-order traversal
void displayPreOrder(Node* root) {
    if (root) {
        cout << root->data << " ";
        displayPreOrder(root->left);
        displayPreOrder(root->right);
    }
}

// Function to display leaf nodes
void displayLeafNodes(Node* root) {
    if (root) {
        if (!root->left && !root->right)
            cout << root->data << " ";
        displayLeafNodes(root->left);
        displayLeafNodes(root->right);
    }
}

int main() {
    Node* root = nullptr;

    // Inserting nodes into the binary tree
    root = insert(root, 10);
    insert(root, 5);
    insert(root, 15);
    insert(root, 3);
    insert(root, 7);
    insert(root, 12);
    insert(root, 18);

    // Displaying the binary tree
    cout << "In-order Display: ";
    displayInOrder(root);
    
    cout << "\nPre-order Display: ";
    displayPreOrder(root);

    cout << "\nLeaf Nodes: ";
    displayLeafNodes(root);

    return 0;
}