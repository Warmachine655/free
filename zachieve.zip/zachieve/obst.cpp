#include <iostream>
#include <climits>

using namespace std;

// Function to calculate the sum of frequencies from freq[i] to freq[j]
int sum(int freq[], int i, int j) {
    int total = 0;
    for (int k = i; k <= j; k++) {
        total += freq[k];
    }
    return total;
}

// Function to find the minimum cost of an Optimal Binary Search Tree
int optimalSearchTree(int keys[], int freq[], int n) {
    // Create a 2D array to store the cost of optimal BST
    int cost[n][n];

    // Initialize the cost for single keys
    for (int i = 0; i < n; i++) {
        cost[i][i] = freq[i];
    }

    // Build the cost table in a bottom-up manner
    for (int length = 2; length <= n; length++) { // Length of the subarray
        for (int i = 0; i <= n - length; i++) { // Starting index of the subarray
            int j = i + length - 1; // Ending index
            cost[i][j] = INT_MAX; // Initialize to maximum
            
            // Try making each key in the range as root
            for (int r = i; r <= j; r++) {
                // Calculate cost when keys[r] is root
                int c = ((r > i) ? cost[i][r - 1] : 0) + 
                        ((r < j) ? cost[r + 1][j] : 0) + 
                        sum(freq, i, j);
                
                // Update minimum cost
                if (c < cost[i][j]) {
                    cost[i][j] = c;
                }
            }
        }
    }
    
    // Return the minimum cost for the whole tree
    return cost[0][n - 1];
}

// Driver program to test above functions
int main() {
    int keys[] = {10, 12, 20}; // Keys must be sorted
    int freq[] = {34, 8, 50};   // Frequencies corresponding to keys
    int n = sizeof(keys) / sizeof(keys[0]);
    
    cout << "Cost of Optimal BST is: " << optimalSearchTree(keys, freq, n) << endl;
    
    return 0;
}