#include <iostream>
#include <vector>
#include <list>
using namespace std;

class HashTable {
private:
    int buckets;
    vector<list<pair<int, int>>> table;

    int hashFunction(int key) {
        return key % buckets;
    }

public:
    HashTable(int b) : buckets(b), table(b) {}

    void insert(int key, int value) {
        int index = hashFunction(key);
        for (auto &pair : table[index]) {
            if (pair.first == key) {
                pair.second = value; // Update if key exists
                return;
            }
        }
        table[index].emplace_back(key, value); // Add new key-value pair
    }

    int search(int key) {
        int index = hashFunction(key);
        for (const auto &pair : table[index]) {
            if (pair.first == key) return pair.second; // Return found value
        }
        return -1; // Not found
    }

    void remove(int key) {
        int index = hashFunction(key);
        table[index].remove_if([key](const auto& p) { return p.first == key; });
    }

    void display() const {
        for (int i = 0; i < buckets; i++) {
            cout << "Bucket " << i << ": ";
            for (const auto &pair : table[i]) {
                cout << "[" << pair.first << ": " << pair.second << "] ";
            }
            cout << endl;
        }
    }
};

int main() {
    HashTable ht(7);
    ht.insert(10, 100);
    ht.insert(20, 200);
    ht.insert(30, 300);
    ht.insert(10, 150); // Update existing key

    cout << "Value for key 10: " << ht.search(10) << endl; // Should return 150
    ht.remove(20); // Remove key 20

    cout << "After removing key 20:" << endl;
    ht.display(); // Display current state of hash table

    return 0;
}