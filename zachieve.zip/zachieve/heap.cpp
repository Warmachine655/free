#include <iostream>
#include <vector>
using namespace std;

class MaxHeap {
private:
    vector<int> heap;

    void heapifyUp(int index) {
        while (index > 0 && heap[(index - 1) / 2] < heap[index]) {
            swap(heap[index], heap[(index - 1) / 2]);
            index = (index - 1) / 2;
        }
    }

public:
    void insert(int value) {
        heap.push_back(value);
        heapifyUp(heap.size() - 1);
    }

    int getMax() const {
        if (heap.empty()) throw out_of_range("Heap is empty");
        return heap[0];
    }
};

int main() {
    MaxHeap maxHeap;
    int n, mark;

    cout << "Enter number of students: ";
    cin >> n;

    cout << "Enter marks obtained by each student:\n";
    for (int i = 0; i < n; i++) {
        cin >> mark;
        maxHeap.insert(mark);
    }

    try {
        cout << "Maximum marks obtained: " << maxHeap.getMax() << endl;
    } catch (const out_of_range& e) {
        cout << e.what() << endl;
    }

    return 0;
}
