#include <iostream>
#include <string>
using namespace std;

class stack
{
public:
    string stk[20];
    int top;
    stack()
    {
        top = -1;
    }

    void push(string x)
    {
        if (top == 19)
        {
            cout << "Stack overflow" << endl;
            return;
        }
        stk[++top] = x;
    }

    void pop()
    {
        if (top == -1)
        {
            cout << "Stack is empty. Cannot pop\n";
            return;
        }
        top--;
    }

    string topElement()
    {
        if (top == -1)
        {
            return "";  // Empty stack, return empty string
        }
        return stk[top];
    }

    void display()
    {
        for (int i = 0; i <= top; i++)
        {
            cout << stk[i] << endl;
        }
    }
};

void printReversedString(const string& str)
{
    stack s;
    for (char c : str)
    {
        s.push(string(1, c)); // Push each character as string
    }

    cout << "Original string: " << str << endl;
    cout << "Reversed string: ";
    while (!s.topElement().empty()) // Check if stack is empty
    {
        cout << s.topElement();
        s.pop();
    }
    cout << endl;
}

bool isPalindrome(const string& str)
{
    stack s;
    for (char c : str)
    {
        s.push(string(1, c)); // Push each character as string
    }

    string reversedStr;
    while (!s.topElement().empty())
    {
        reversedStr += s.topElement();
        s.pop();
    }

    return str == reversedStr; // Check if original string matches reversed
}

int main()
{
    string str;
    cout << "Enter a string: ";
    cin >> str;

    printReversedString(str);

    if (isPalindrome(str))
    {
        cout << "The string is a palindrome." << endl;
    }
    else
    {
        cout << "The string is not a palindrome." << endl;
    }

    return 0;
}
