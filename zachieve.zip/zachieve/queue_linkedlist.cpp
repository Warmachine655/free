#include <iostream>
using namespace std;

// Node structure for linked list
struct Node {
    int data; // Data part of the node
    Node* next; // Pointer to the next node
};

// Queue class using linked list
class Queue {
private:
    Node* front; // Pointer to the front of the queue
    Node* rear; // Pointer to the rear of the queue

public:
    Queue() {
        front = nullptr; // Initialize front to null
        rear = nullptr; // Initialize rear to null
    }

    // Function to add an element to the queue
    void enqueue(int value) {
        Node* newNode = new Node(); // Create a new node
        newNode->data = value; // Set node data
        newNode->next = nullptr; // New node will be at the end, so next is null

        if (front == nullptr) { // Check if the queue is empty
            front = rear = newNode; // If queue is empty, both front and rear point to new node
        } else {
            rear->next = newNode; // Link the old rear to the new node
            rear = newNode; // Update rear to point to the new node
        }
        cout << value << " enqueued to queue." << endl;
    }

    // Function to remove an element from the queue
    int dequeue() {
        if (front == nullptr) { // Check if the queue is empty
            cout << "Queue is empty! Cannot dequeue." << endl;
            return -1; // Indicate empty queue
        }
        int dequeuedValue = front->data; // Get value from front node
        Node* temp = front; // Store current front node for deletion
        front = front->next; // Move front pointer to the next node

        if (front == nullptr) { // If queue becomes empty after dequeue
            rear = nullptr; // Update rear as well
        }
        
        delete temp; // Free memory of old front node
        return dequeuedValue; // Return dequeued value
    }

    // Function to display elements of the queue
    void display() {
        if (front == nullptr) { // Check if the queue is empty
            cout << "Queue is empty." << endl;
            return;
        }
        Node* temp = front;
        cout << "Queue elements: ";
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

// Main function to demonstrate queue operations
int main() {
    Queue queue;

    // Enqueue elements
    queue.enqueue(10);
    queue.enqueue(20);
    queue.enqueue(30);
    
    // Display current elements in the queue
    queue.display();

    // Dequeue an element and display it
    cout << "Dequeued: " << queue.dequeue() << endl;

    // Display current elements in the queue after dequeue
    queue.display();

    return 0;
}
