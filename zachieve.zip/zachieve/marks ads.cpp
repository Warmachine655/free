#include <iostream>
using namespace std;

// Structure for a tree node
struct Node {
    int marks;
    Node* left;
    Node* right;

    Node(int value) : marks(value), left(nullptr), right(nullptr) {}
};

// Function to insert a new mark into the BST
Node* insert(Node* root, int value) {
    if (!root) return new Node(value);
    if (value < root->marks)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);
    return root;
}

// Function to print marks in ascending order (in-order traversal)
void printMarksInOrder(Node* root) {
    if (root) {
        printMarksInOrder(root->left);
        cout << root->marks << " ";
        printMarksInOrder(root->right);
    }
}

// Function to find the minimum mark
int findMin(Node* root) {
    if (!root) {
        cout << "The tree is empty." << endl;
        return -1; // Indicating an error
    }
    Node* current = root;
    while (current->left) {
        current = current->left;
    }
    return current->marks;
}

// Function to find the maximum mark
int findMax(Node* root) {
    if (!root) {
        cout << "The tree is empty." << endl;
        return -1; // Indicating an error
    }
    Node* current = root;
    while (current->right) {
        current = current->right;
    }
    return current->marks;
}

int main() {
    Node* root = nullptr;

    // Example student marks for ADS
    int marksArray[] = {85, 70, 90, 60, 75, 95, 80};
    
    // Inserting marks into the BST
    for (int mark : marksArray) {
        root = insert(root, mark);
    }

    // Printing marks in ascending order
    cout << "Marks in Ascending Order: ";
    printMarksInOrder(root);
    
    // Finding and printing minimum and maximum marks
    cout << "\nMinimum Marks: " << findMin(root);
    cout << "\nMaximum Marks: " << findMax(root);

    return 0;
}