#include <iostream>
#include <stack>

using namespace std;

void decimalToBinary(int decimal) {
    // Create a stack to hold the binary digits
    stack<int> binaryStack;

    // Handle the case when the decimal number is 0
    if (decimal == 0) {
        cout << "Binary: 0" << endl;
        return;
    }

    // Convert decimal to binary by repeatedly dividing by 2
    while (decimal > 0) {
        int remainder = decimal % 2; // Get the remainder (binary digit)
        binaryStack.push(remainder);  // Push it onto the stack
        decimal /= 2;                 // Divide the number by 2
    }

    // Pop elements from the stack to get the binary representation
    cout << "Binary: ";
    while (!binaryStack.empty()) {
        cout << binaryStack.top(); // Print the top element of the stack
        binaryStack.pop();         // Remove it from the stack
    }
    cout << endl; // New line for better output formatting
}

int main() {
    int decimalNumber;

    // Input from user
    cout << "Enter a decimal number: ";
    cin >> decimalNumber;

    // Call the function to convert and display binary representation
    decimalToBinary(decimalNumber);

    return 0;
}
