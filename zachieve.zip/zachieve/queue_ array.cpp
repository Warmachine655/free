#include <iostream>
using namespace std;

#define MAX 100 // Maximum size of the queue

class Queue {
private:
    int arr[MAX]; // Array to store queue elements
    int front, rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }


    // Add element to the queue
    void enqueue(int value) {
        if (rear == MAX - 1) {
            cout << "Queue is full!" << endl;
        } else {
            if (front == -1) front = 0;
            arr[++rear] = value;
            cout << value << " enqueued." << endl;
        }
    }

    // Remove element from the queue
    int dequeue() {
        if (front == -1) {
            cout << "Queue is empty!" << endl;
            return -1;
        }
        int value = arr[front++];
        if (front > rear) front = rear = -1; // Reset queue if empty
        return value;
    }

    // Display elements in the queue
    void display() {
        if (front == -1) {
            cout << "Queue is empty." << endl;
        } else {
            for (int i = front; i <= rear; i++) {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
    }
};

// Main function to demonstrate queue operations
int main() {
    Queue queue;

    queue.enqueue(10);
    queue.enqueue(20);
    queue.enqueue(30);
    queue.display();

    cout << "Dequeued: " << queue.dequeue() << endl;
    queue.display();

    return 0;
}
