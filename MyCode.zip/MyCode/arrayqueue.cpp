#include <iostream>
using namespace std;

class queue{
    int *arr;
    int front,rear,size;

    public:
    queue(int n){
        size = n ;
        front = rear = -1;
        arr = new int [n];
    }

    bool IsEmpty(){
        return front == -1;
    }

    bool IsFull(){
        return rear == size-1;
    }

    void enqueue(int x)
    {
        if(IsFull())
        {
            cout<< " queue overflow "<<endl;
            
        }
        else if(IsEmpty())
        {
            front = rear = 0;
            arr[0] = x;
            cout<<" add "<< x <<" into queue "<<endl;
        }
        else
        {
            rear = rear + 1;
            arr[rear] = x;
            cout<<" add "<< x <<" into queue "<<endl;
        }
    }

    void dequeue(){
        if(IsEmpty()){
            cout<<" queue underflow "<<endl;
        }
        else if(front==rear)
        {   cout<<" remove "<< arr[front] <<" into queue "<<endl;
            front = rear = -1;

        }
        else{
            cout<<" remove "<< arr[front] <<" into queue "<<endl;
            front = front + 1;
        }
    }

   int start()
   {
    if(IsEmpty())
    {
        cout<<" queue is empty "<<endl;
        return -1;
    }
    else
    {
        return arr[front];
    }
   }
};

int main(){
    queue s(5);
    s.enqueue(6);
    s.enqueue(2);
    s.enqueue(9);
    s.enqueue(17);
    s.dequeue();
    cout<<" Is queue empty: "<< s.IsEmpty()<<endl;
    cout<<" Front Element is: "<< s.start()<<endl;
    return 0;
}

    