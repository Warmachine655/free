#include <iostream>
using namespace std;

class Node{
    public:
    int data;
    Node *next;
    
    Node(int k){
        data = k;
        next = NULL;
    }
};

class queue{
    private:
    Node *front;
    Node *rear;

    public:
    queue(){
        front = rear = NULL;
    }

    bool IsEmpty(){
        return front == NULL;
    }

    void enqueue(int x){
        if(IsEmpty()){
            cout<<" add "<< x <<" into the queue "<<endl;
            front = rear = new Node(x);
        }
        else 
        {
            cout<<" add "<< x <<" into the queue "<<endl;
            rear->next = new Node(x);
            rear = rear->next;
        }
    }

    void dequeue(){
        if(IsEmpty()){
            cout<<"queue underflow "<<endl;
        }
        else
        {
            cout<<" remove "<< front->data <<" from the queue "<<endl;
            Node *temp = front;
            front = front->next;
            delete temp;
        }
    }

    int start(){
        if(IsEmpty())
        {
            cout<<" queue is empty "<<endl;
            return -1;
        }
        else{
            return front->data;
        }
    }
   
};

int main()
{
    queue y;
    y.enqueue(9);
    y.enqueue(5);
    y.enqueue(56);
    y.dequeue();
    y.enqueue(78);
    y.dequeue();
    y.dequeue();
    y.enqueue(34);
    y.enqueue(11);
    cout<<"top element is: "<< y.start() <<endl;

    return 0;
}
