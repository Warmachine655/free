#include <iostream>
#include <stack>
using namespace std;

void decimaltobinary(int binarynumber) {
    if (binarynumber == 0) {
        cout << "Binary: 0" << endl;
        return;
    }

    stack<int> st;
    while (binarynumber > 0) {
        int remainder = binarynumber % 2;
        st.push(remainder);
        binarynumber /= 2;
    }

    cout << "Binary Number: ";
    while (!st.empty()) {
        cout << st.top();
        st.pop();
    }
    cout << endl;
}

int main() {
    int decimalNumber;
    cout << "Enter Decimal Number: "; // Fixed the input prompt for clarity
    cin >> decimalNumber;

    decimaltobinary(decimalNumber);
    return 0;
}
