#include <iostream>
using namespace std;

class Node 
{
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = NULL;
    }
};

class Stack {
private:
    Node* top;
    int size;

public:
    // Constructor
    Stack() {
        top = NULL;
        size = 0;
    }

    // Push an element onto the stack
    void push(int value) {
        Node* temp = new Node(value);
        if (temp == NULL) {
            cout << "Stack overflow" << endl;
            return;
        }
        temp->next = top;
        top = temp;
        size++;
        cout << "Pushed " << value << " into the stack" << endl;
    }

    // Pop an element from the stack
    void pop() {
        if (top == NULL) {
            cout << "Stack underflow" << endl;
            return;
        }
        Node* temp = top;
        top = top->next;
        cout << "Popped " << temp->data << " from the stack" << endl;
        delete temp;
        size--;
    }

    // Peek at the top element
    int peek() {
        if (top == NULL) {
            cout << "Stack is empty" << endl;
            return -1;
        }
        return top->data;
    }

    // Check if the stack is empty
    bool isEmpty() {
        return top == NULL;
    }

    // Get the size of the stack
    int stackSize() {
        return size;
    }
};

int main() {
    Stack harsh;
    harsh.push(3);
    harsh.push(8);
    harsh.push(2);
    cout << "Top element: " << harsh.peek() << endl;
    harsh.pop();
    harsh.pop();
    harsh.pop();
    cout << "Stack size: " << harsh.stackSize() << endl;
    harsh.peek();

    return 0;
}
