#include <iostream>
#include <cctype>
#include <stack>
using namespace std;
class Node{
    public:
    char data;
    Node *left;
    Node *right;

    Node(char value){
        data = value;
        left = right = NULL;
    }
};

Node *constructexpressiontree(string postfix){
    stack<Node*>st;
    for(char ch : postfix){
        if(isdigit(ch) || isalpha(ch)){
            st.push(new Node(ch));

        }
        else
        {
            Node *right = st.top();
            st.pop();
            Node *left = st.top();
            st.pop();

            Node *node = new Node (ch);
            node->left = left;
            node->right = right;
            st.push(node);
        }
    }
    return st.top();
}
 
void inorder(Node* root) {
    if (root != NULL) {
        inorder(root->left);
        cout << root->data << " ";
        inorder(root->right);
    }
}

void preOrder(Node* root) {
    if (root != NULL) {
        cout << root->data << " ";
        preOrder(root->left);
        preOrder(root->right);
    }
}

void postOrder(Node* root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        cout << root->data << " ";
    }
}

int main(){

    string postfix = "AB-CD+*";

    Node *root = constructexpressiontree(postfix);

    cout << "In-order Traversal: ";
    inorder(root);

    cout << "\nPre-order Traversal: ";
    preOrder(root);

    cout << "\nPost-order Traversal: ";
    postOrder(root);
    
    return 0;
}