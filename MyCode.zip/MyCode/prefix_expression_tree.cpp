#include <iostream>
#include <cctype> // For isdigit
#include <stack>
using namespace std;

class Node {
public:
    char data;
    Node* left;
    Node* right;

    Node(char value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

// Function to construct an expression tree from prefix expression
Node* constructExpressionTree(string prefix, int& index) {
    if (index >= prefix.size())
        return NULL;

    // Create a new node for the current character
    Node* node = new Node(prefix[index]);

    // If the current character is an operator, recursively construct its children
    if (!isdigit(prefix[index]) && !isalpha(prefix[index])) {
        index++;
        node->left = constructExpressionTree(prefix, index);
        index++;
        node->right = constructExpressionTree(prefix, index);
    }

    return node;
}

// In-order traversal (left, root, right)
void display(Node* root) {
    if (root != NULL) {
        display(root->left);
        cout << root->data << " ";
        display(root->right);
    }
}

// Pre-order traversal (root, left, right)
void preOrder(Node* root) {
    if (root != NULL) {
        cout << root->data << " ";
        preOrder(root->left);
        preOrder(root->right);
    }
}

// Post-order traversal (left, right, root)
void postOrder(Node* root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        cout << root->data << " ";
    }
}

int main() {
    string prefix = "*+AB-CD"; // Example prefix expression
    int index = 0; // To track the current position in the prefix string

    // Construct the expression tree
    Node* root = constructExpressionTree(prefix, index);

    // Display the tree using various traversals
    cout << "In-order Traversal: ";
    display(root);
    cout << "\nPre-order Traversal: ";
    preOrder(root);
    cout << "\nPost-order Traversal: ";
    postOrder(root);

    return 0;
}
