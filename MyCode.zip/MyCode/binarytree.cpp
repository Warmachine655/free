#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

// Function to insert a node (without BST rules)
Node* insert(Node* root, int value) {
    if (root == NULL)
        return new Node(value);

    // Insert at the left if possible, otherwise go to the right.
    if (root->left == NULL) {
        root->left = new Node(value);
    } else if (root->right == NULL) {
        root->right = new Node(value);
    } else {
        // If both children are present, just insert in the left subtree (as an example).
        insert(root->left, value);  // This can be modified to any insertion strategy.
    }
    return root;
}

// Function to display the tree (in-order traversal)
void display(Node* root) {
    if (root != NULL) {
        display(root->left);
        cout << root->data << " ";
        display(root->right);
    }
}

// Function to display leaf nodes
void displayLeafNodes(Node* root) {
    if (root) {
        if (!root->left && !root->right)
            cout << root->data << " ";
        displayLeafNodes(root->left);
        displayLeafNodes(root->right);
    }
}

// Pre-order traversal (root, left, right)
void preOrder(Node* root) {
    if (root != NULL) {
        cout << root->data << " ";
        preOrder(root->left);
        preOrder(root->right);
    }
}

// Post-order traversal (left, right, root)
void postOrder(Node* root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        cout << root->data << " ";
    }
}

int main() {
    Node* root = NULL;
    root = insert(root, 17);
    insert(root, 5);
    insert(root, 4);
    insert(root, 31);
    insert(root, 7);
    insert(root, 17);

    
    cout << "In-order Display: ";
    display(root);
    cout << "\nLeaf Nodes: ";
    displayLeafNodes(root);
    cout << "\nPre-order Traversal: ";
    preOrder(root);
    cout << "\nPost-order Traversal: ";
    postOrder(root);

    return 0;
}
