#include <iostream>
#include <vector>
#include <climits>

using namespace std;

// Function to find the vertex with the minimum key value
int findMinVertex(vector<int>& key, vector<bool>& inMST, int V) {
    int minKey = INT_MAX, minIndex;
    for (int v = 0; v < V; v++) {
        if (!inMST[v] && key[v] < minKey) {
            minKey = key[v];
            minIndex = v;
        }
    }
    return minIndex;
}

// Function to implement Prim's Algorithm
void primMST(vector<vector<int>>& graph, int V) {
    vector<int> parent(V, -1); // Array to store constructed MST
    vector<int> key(V, INT_MAX); // Key values to pick minimum weight edge
    vector<bool> inMST(V, false); // To keep track of vertices included in MST

    // Start with the first vertex
    key[0] = 0; // Make key value of the first vertex as 0

    for (int count = 0; count < V - 1; count++) {
        // Pick the minimum key vertex not yet included in MST
        int u = findMinVertex(key, inMST, V);

        // Include the picked vertex in the MST
        inMST[u] = true;

        // Update key and parent of adjacent vertices
        for (int v = 0; v < V; v++) {
            // Update the key only if graph[u][v] is smaller and v is not in MST
            if (graph[u][v] && !inMST[v] && graph[u][v] < key[v]) {
                key[v] = graph[u][v];
                parent[v] = u;
            }
        }
    }

    // Print the MST
    cout << "Edge\tWeight\n";
    for (int i = 1; i < V; i++) {
        cout << parent[i] << " - " << i << "\t" << graph[i][parent[i]] << endl;
    }
}

int main() {
    int V;
    cout << "Enter the number of vertices: ";
    cin >> V;

    vector<vector<int>> graph(V, vector<int>(V));
    cout << "Enter the adjacency matrix of the graph:\n";
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            cin >> graph[i][j];
        }
    }

    primMST(graph, V);

    return 0;
}
