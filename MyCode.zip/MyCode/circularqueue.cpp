#include <iostream>
using namespace std;

class queue{
    public:
    int *arr;
    int front,rear;
    int size;
    
    queue(int z){
        size = z;
        front = rear = -1;
        arr = new int[z];
    }

    bool IsEmpty(){
        return front == -1;
    }

    bool IsFull(){
        return (rear + 1) % size == front;
    }

    void enqueue(int x){
        if(IsFull()){
            cout<<" queue overflow "<<endl;
        }
        else if(IsEmpty()){
            cout<<" add "<< x << " into the queue "<<endl;
            front = rear = 0;
            arr[0] = x;
        }
        else{
            cout<<" add "<< x << " into the queue "<<endl;
            rear = (rear + 1) % size;
            arr[rear] = x;
        }
    }
    
    void dequeue(){
        if(IsEmpty()){
            cout<<" queue underflow "<<endl;
        }
        else if(front == rear){
             cout<<" remove "<< arr[front] << " from the queue "<<endl;
            front = rear = -1;
        }
        else{
            cout<<" remove "<< arr[front] << " from the queue "<<endl;
            front = (front + 1) % size;

        }
    }
};

int main(){
    queue d(5);
    d.enqueue(3);
    d.enqueue(7);
    d.enqueue(11);
    d.enqueue(17);
    d.enqueue(6);
    d.dequeue();
    d.dequeue();
    d.enqueue(4);
    d.enqueue(65);
    d.enqueue(13);
    return 0;
}