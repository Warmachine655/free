#include <iostream>
using namespace std;

class stack{
    int *arr;
    int size;
    int top;

    public:
    stack(int s){
        size = s;
        top = -1;
        arr = new int[s];
    }

    void push(int value){
        if(top == size - 1){
            cout << "stack overflow" << endl;
        }
        else{
            top++;
            arr[top] = value;
            cout << "Push " << value << " into stack" << endl;
        }
    }

    void pop(){
        if(top == -1){
            cout << "stack underflow" << endl;
        }
        else{
            cout << "Pop " << arr[top] << " from stack" << endl;
            top--;
        }
    }

    int peek(){
        if(top == -1){
            cout << "stack is empty" << endl;
            return -1;
        }
        else{
            cout << "Top element is: " << arr[top] << endl;
            return arr[top];
        }
    }

    bool Isempty(){
        return top == -1;
    }

    int stack_size(){
        return top + 1;
    }

};

int main(){
    stack harsh(5);
    harsh.push(3);
    harsh.push(8);
    harsh.push(2);
    harsh.pop();
    harsh.pop();
    harsh.pop();
    harsh.peek();
    cout << "Current stack size: " << harsh.stack_size() << endl;
    return 0;
}
