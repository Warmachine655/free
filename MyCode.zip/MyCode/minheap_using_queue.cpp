#include <iostream>
#include <queue>
#include <vector>
using namespace std;

int main(){
    int h;
    cout<<" Enter the number student in class: ";
    cin>>h;

    priority_queue<int, vector<int>, greater<int>> minheap;
    cout<<" Enter the marks obtain by student: "<<endl;
    for(int i=0;i<h;i++){
        int marks;
        cin>>marks;
        minheap.push(marks);
    }
    if(!minheap.empty()){
        int minmarks = minheap.top();
        cout<<" Minimun mark obtain by student: "<<minmarks;
    }
    else{
        cout<<"No Marks were obtain.";
    }
    return 0;
}