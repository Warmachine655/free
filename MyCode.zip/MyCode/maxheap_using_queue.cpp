#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main(){
    int v;
    cout<<" Enter the number student in class; ";
    cin>>v;

    priority_queue<int> maxheap;

    cout<<" Enter the marks obtain by students:"<<endl;
    for(int i=0;i<v;i++){
        int marks;
        cin>>marks;
        maxheap.push(marks);
    }

    if(maxheap.empty()==0){
        int maxmark = maxheap.top();
        cout<<" The maximum mark btain by student: "<< maxmark ;
    }
    else{
        cout<<" No Marks were entered.";
    }


    return 0;
}