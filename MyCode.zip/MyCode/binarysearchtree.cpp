#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

// Function to insert a node
Node* insert(Node* root, int value) {
    if (root == NULL)
        return new Node(value);
    if (value < root->data)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);
    return root;
}

// Function to display the tree (in-order traversal)
void inOrder(Node* root) {
    if (root != NULL) {
        inOrder(root->left);
        cout << root->data << " ";
        inOrder(root->right);
    }
}


// Pre-order traversal (root, left, right)
void preOrder(Node* root) {
    if (root != NULL) {
        cout << root->data << " ";
        preOrder(root->left);
        preOrder(root->right);
    }
}

// Post-order traversal (left, right, root)
void postOrder(Node* root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        cout << root->data << " ";
    }
}

void displayLeafNodes(Node* root) {
    if (root!=NULL) {
        if (root->left == NULL && root->right == NULL)
            cout << root->data << " ";
        displayLeafNodes(root->left);
        displayLeafNodes(root->right);
    }
}

int main() {
    Node* root = NULL;
    root = insert(root, 28);
    insert(root, 5);
    insert(root, 15);
    insert(root, 31);
    insert(root, 27);
    insert(root, 11);
    insert(root, 23);

    cout << "In-order Display: ";
    inOrder(root);
    cout << "\nLeaf Nodes: ";
    displayLeafNodes(root);
    cout << "\nPre-order Traversal: ";
    preOrder(root);
    cout << "\nPost-order Traversal: ";
    postOrder(root);

    return 0;
}
