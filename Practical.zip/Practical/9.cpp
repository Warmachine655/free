//Store the final marks of students for subject ADS using BST and perform following operations. 1.Print marks in ascending order 2.Print min and max marks

#include<iostream>
using namespace std;

struct Node{
    int data;
    Node*left;
    Node*right;
    Node(int val){
        data = val;
        left = nullptr;
        right = nullptr;
    }
};

class binaryTree{
private:
    Node*root;

    Node*insert(Node*node , int data){
        if(node == nullptr){
            return new Node(data);
        }
        if(data < node->data){
            node->left = insert(node->left , data);
        }
        else{
            node->right = insert(node->right , data);
        }
        return node;
    }

    void inOrder(Node*node){
        if(node != nullptr){
            inOrder(node->left);
            cout<<node->data<<" ";
            inOrder(node->right);
        }
    }

    Node*findMax(Node*node){
        while(node && node->right){
            node = node->right;
        }
        return node;
    }

    Node*findMin(Node*node){
        while(node && node->left){
            node = node->left;
        }
        return node;
    }

public:
    binaryTree(){
        root = nullptr;
    }

    void Insert(int data){
        root = insert(root , data);
        cout<<data<<" added sucessfully.\n";
    }

    void display(){
        cout<<"Marks of students are: ";
        inOrder(root);
        cout<<endl;
    }

    int getMin(){
        Node*minNode = findMin(root);
        return minNode ? minNode->data : -1;
    }

    int getMax(){
        Node*maxNode = findMax(root);
        return maxNode ? maxNode->data : -1;
    }
};

int main(){
    binaryTree bt;

    bt.Insert(50);
    bt.Insert(30);
    bt.Insert(70);
    bt.Insert(20);
    bt.Insert(40);
    bt.Insert(60);
    bt.Insert(80);

    // Print marks in ascending order
    cout << "Marks in ascending order: ";
    bt.display();

    // Print the minimum and maximum marks
    cout << "Minimum marks: " << bt.getMin() << endl;
    cout << "Maximum marks: " << bt.getMax() << endl;

    return 0;
}