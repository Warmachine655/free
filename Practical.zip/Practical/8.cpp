//Create Binary Tree and perform operations 1. Insert 2. Display inorder and preorder 3. Display Leaf Nodes

#include<iostream>
using namespace std;

struct Node{
    int data;
    Node*left;
    Node*right;
    Node(int val){
        data = val;
        left = nullptr;
        right = nullptr;
    }
};

class binaryTree{
private:
    Node*root;

    Node*insert(Node*node , int data){
        if(node == nullptr){
            return new Node(data);
        }
        if(data < node->data){
            node->left = insert(node->left, data);
        }
        else{
            node->right = insert(node->right , data);
        }
        return node;
    }

    void inOrder(Node*node){
        if(node != nullptr){
            inOrder(node->left);
            cout<<node->data<<" ";
            inOrder(node->right);
        }
    }
    void preOrder(Node*node){
        if(node != nullptr){
            cout<<node->data<<" ";
            preOrder(node->left);
            preOrder(node->right);
        }
    }

    void displayLeafNodes(Node*node){
        if(node != nullptr){
            if(node->right == nullptr && node->left == nullptr){
                cout<<node->data<<" ";
            }
            displayLeafNodes(node->left);
            displayLeafNodes(node->right);
        }
    }

public:
    binaryTree(){
        root = nullptr;
    }

    void insert(int data){
        root = insert(root, data);
    }

    void inOrder(){
        if(root == nullptr){
            cout<<"Tree is empty\n";
            return ;
        }
        cout<<"Inorder traversal: ";
        inOrder(root);
        cout<<endl;
    }

    void preOrder(){
        if(root == nullptr){
            cout<<"Tree is empty\n";
            return ;
        }
        cout<<"Preorder traversal: "; 
        preOrder(root);
        cout<<endl;
    }

    void displayLeafNodes(){
        if(root == nullptr){
            cout<<"Tree is empty\n";
            return ;
        }
        cout<<"Leaf noodes are: ";
        displayLeafNodes(root);
        cout<<endl;
    }
};

int main(){
    binaryTree bt;
    int choice, data;

    do{
        cout << "\n1. Insert\n2. Display In-order\n3. Pre-order\n4. Display Leaf Nodes\n5. Exit\nEnter your choice: ";
        cin >> choice;
        switch(choice){
            case 1:
                cout<<"Enter a value: ";
                cin>>data;
                cout<<endl;
                bt.insert(data);
                break;
            case 2:
                bt.inOrder();
                break;
            case 3:
                bt.preOrder();
                break;
            case 4:
            cout<<"Leaf nodes are: ";
                bt.displayLeafNodes();
                break;
            case 5:
                cout<<"exiting a program...\n";
                break;
            default:
                cout<<"Enter a valid number(1-5)";
        }
    }
    while(choice !=5);
    return 0;
}