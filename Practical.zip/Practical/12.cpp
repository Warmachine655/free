
#include <iostream>
#include <stack>
#include <cctype>

using namespace std;


struct TreeNode {
    char data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(char val) : data(val), left(nullptr), right(nullptr) {}
};


bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}


TreeNode* constructExpressionTree(const string& postfixExpression) {
    stack<TreeNode*> stk;

    for (int i = 0; i< postfixExpression.size();i++) {
        char currentChar = postfixExpression[i];

        if (isalnum(currentChar)) {
           
            stk.push(new TreeNode(currentChar));
        } else if (isOperator(currentChar)) {
            
            TreeNode* operand1 = stk.top();
            stk.pop();

            TreeNode* operand2 = stk.top();
            stk.pop();

          
            TreeNode* newNode = new TreeNode(currentChar);

          
            newNode->left = operand2;
            newNode->right = operand1;

           
            stk.push(newNode);
        }
    }

   
    return stk.top();
}


void inorderTraversal(TreeNode* root) {
    if (root) {
        inorderTraversal(root->left);
        cout << root->data << " ";
        inorderTraversal(root->right);
    }
}


int main() {
   
    string postfixExpression;
    cout << "Enter the postfix expression: ";
    cin >> postfixExpression;

   
    TreeNode* root = constructExpressionTree(postfixExpression);

   
    cout << "Inorder traversal: ";
    inorderTraversal(root);
    
    return 0;
}