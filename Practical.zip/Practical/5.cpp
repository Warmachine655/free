//Write a Program to Implement queue operations using  Linked List

#include<iostream>
using namespace std;

struct node{
    int data;
    node*next;
};
class Queue{
private:
    node*front;
    node*rear;
public:
    Queue(){
        front = nullptr;
        rear = nullptr;
    }

    ~Queue() {
        while (!isempty()) {
            dequeue(); // Remove all nodes
        }
    }

    bool isempty(){
        return front == nullptr;
    }

    void enqueue(int data){
        node*newnode = new node();
        newnode->data = data;
        newnode->next = nullptr;
        if(isempty()){
            front = rear = newnode;
        }
        else{
            rear->next = newnode;
            rear = newnode;
        }
        cout<<data<<" added sucessfully\n";
    }

    int dequeue(){
        if(isempty()){
            cout<<"Queue is empty\n";
            return -1;
        }
        node*temp = front;
        int data = temp->data;
        front = front->next;
        if(front == nullptr){
            rear = nullptr;
        }
        delete temp;
        cout<<"Data removed = "<<data<<endl;
        return data;
    }

    int peek(){
        if (isempty()){
            cout<<"queue is empty\n";
            return -1;
        }
        cout<<front->data<<" is first element of queue\n";
        return front->data;
    }

    void display(){
        if(isempty()){
            cout<<"Queue is empty\n";
        }
        cout<<"Elements of queue are: \n";
        node*temp = front;
        while(temp!=nullptr){
            cout<<temp->data<<"->";
            temp = temp->next;
        }
        cout<<"NULL\n";
    }
};

int main(){
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display(); // Should print: Queue elements are: 10 20 30

    q.peek(); // Should print: 10 is at the front of the queue

    q.dequeue(); // Should remove 10
    q.display(); // Should print: Queue elements are: 20 30

    q.dequeue(); // Should remove 20
    q.dequeue(); // Should remove 30
    q.dequeue(); // Should print: Queue is empty

    q.enqueue(40);
    q.enqueue(50);
    q.display(); // Should print: Queue elements are: 40 50

    return 0;
}