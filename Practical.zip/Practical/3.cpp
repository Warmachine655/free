
#include <iostream>
using namespace std;
class st1
{
    public:
    int top;
    st1()
    {
        top=-1;
    }
    char st2[100];
    void push(char,int);
    void pop();
    void reversestring(string);
};
void st1::push(char ch,int top)
{
    if(top==99)
    {
        cout<<"stack is overflow";
    }
    else
    {
        st2[top]=ch;
        cout<<st2[top]<<endl;
    }
}
void st1::pop()
{
    if(top==-1)
    {
        cout<<"stack is underflow";
    }
    else
    {
        top--;
    }
}

void st1::reversestring(string str)
{
    string str2;
    str2=str;
    for (char ch1:str)
    {
        top++;
        push(ch1,top);
    }
    for(int i=0;i<str.length();i++)
    {
        str[i]=st2[top];
        cout<<"stack top   "<<st2[top]<<endl;
        pop();
    }
    cout<<"reversed string   "<<str<<endl;
    if(str2==str){
        cout<<"string is palindrome"<<endl;
        
    }
    else
    {
        cout<<"not palindrome"<<endl;
    }
    
}
int main()
{
    st1 ss;
    
    string str;
    cout<<"enter string to reverse"<<endl;
    cin>>str;
    cout<<"original string"<<str<<endl;
    ss.reversestring(str);
    //cout<<"reversed string"<<str<<endl;
}