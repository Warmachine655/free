/* Circular Queue using Array */

#include <iostream>
using namespace std;

class CircularQueue{
    
    int size;
    int front;
    int rear;
    int* arr;
    
    public:
    
        CircularQueue(int size){
            
            front = -1;
            rear = -1;
            this->size = size;
            arr = new int[size];
        }
    
        void enqueue(){
            
            int data;
            
            cout << "\nEnter data: ";
            cin >> data;
            
            if( (rear+1) % size == front){
                
                cout << "\nQueue OVERFLOW!!" << endl;
                return;
            }
            
            // if queue was initially empty
            
            if(front == -1){
                front = 0;
            }
            
            rear = (rear+1)%size;
            arr[rear] = data;
        }
        
        int dequeue(){
            
            int data;
            
            if(front == -1){
                cout << "Queue UNDERFLOW!!\nNothing to Remove!!";
                return -1;
            }
            
            data = arr[front];
            
            // If there is only one element in the queue
            
            if(rear == front){
                
                front = rear = -1;
                
            } else {
                
                front = (front + 1) % size;
                
            }
            
            
            return data;
            
        }
        
        void display(){
            
            if(front == -1){
                cout << "Queue UNDERFLOW!!\nNothing to Display!!";
                return;
            }
            
            int i = front;
            
            cout << "\nQueue Elements: ";
            
            while(true){
                
                cout << arr[i] << " ";
                
                if (i == rear) {
                    break;
                }
                
                i = (i+1)%size;
                
            }
            
        }
};

int main() {
    
    cout<<"\nHello World\n\n";

    int size;
    int choice;
    int data;
    char ch;

    cout << "Enter Size of Queue: ";
    cin >> size;

    CircularQueue queue(size);

    do {
        
        cout << "\n\n1. Enqueue" << endl
             << "2. Dequeue" << endl
             << "3. Display Queue\n" << endl;

        cout << "\n\nEnter choice number: ";
        cin >> choice;

        switch (choice) {
        case 1:
            queue.enqueue();
            break;

        case 2:
            data = queue.dequeue();

            if (data != -1) {
                cout << "\n\nDequeued " << data << "\n\n" << endl;
            }
            break;

        case 3:
            queue.display();
            break;

        default:
            cout << "Invalid Choice!!" << endl;
            break;
        }

        cout << "\n\nContinue?? (Y/N): ";
        cin >> ch;

    } while (ch == 'y' || ch == 'Y');


    return 0;
}