//Simulate Job Scheduling in Operating System using Queue in FCFS basis 1. Insert 2. Delete 3.Display

#include <iostream>
#include <string>
using namespace std;

struct Node {
    int jobID;
    string jobName;
    Node* next;

    Node(int id, string name) {
        jobID = id;
        jobName = name;
        next = nullptr;
    }
};

class JobQueue {
private:
    Node* front;
    Node* rear;

public:
    JobQueue() {
        front = nullptr;
        rear = nullptr;
    }

    ~JobQueue() {
        while (!isempty()) {
            dequeue();
        }
    }

    bool isempty() {
        return front == nullptr;
    }

    void enqueue(int id, string name) {
        Node* newJob = new Node(id, name);
        if (isempty()) {
            front = rear = newJob;
        } else {
            rear->next = newJob;
            rear = newJob;
        }
        cout << "Job [" << id << "] - " << name << " added successfully.\n";
    }

    void dequeue() {
        if (isempty()) {
            cout << "No jobs to process. Queue is empty.\n";
            return;
        }
        Node* temp = front;
        cout << "Processing Job [" << temp->jobID << "] - " << temp->jobName << ".\n";
        front = front->next;
        if (front == nullptr) {
            rear = nullptr;
        }
        delete temp;
    }

    void display() {
        if (isempty()) {
            cout << "No jobs in the queue.\n";
            return;
        }
        cout << "Jobs in the queue:\n";
        Node* temp = front;
        while (temp != nullptr) {
            cout << "Job [" << temp->jobID << "] - " << temp->jobName << "\n";
            temp = temp->next;
        }
    }
};

int main() {
    JobQueue jq;
    int choice, id;
    string name;

    do {
        cout << "\n1. Insert Job\n2. Delete Job\n3. Display Jobs\n4. Exit\nEnter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                cout << "Enter Job ID: ";
                cin >> id;
                cout << "Enter Job Name: ";
                cin.ignore();
                getline(cin, name);
                jq.enqueue(id, name);
                break;
            case 2:
                jq.dequeue();
                break;
            case 3:
                jq.display();
                break;
            case 4:
                cout << "Exiting the program.\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}