#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node *next;
    node *prev;

    node(int data1)
    {
        data=data1;
        next=NULL;
        prev=NULL;
    }
};

class stack
{
    public:
    node *head;
    node *top;
    int key;

    stack()
    {
        top=NULL;
        head=NULL;
    }

    void push();
    void pop();
    void display();
};

void stack::push()
{
    int data1;
    cout<<"Enter the value: ";
    cin>>data1;
    node *p=new node(data1);
    if(head==NULL && top==NULL)
    {
        head=top=p;
    }
    else
    {
        top->next=p;
        top=p;
    }
}

void stack::pop()
{
    if(head==NULL && top==NULL)
    {
        cout<<"Stack is empty.";
    }
    else
    {
        cout << "The popped element is " << top->data << endl;
        node* temp = top;
        top = top->next;
        delete temp;   }
}

void stack::display()
{
    if(head==NULL && top==NULL)
    {
        cout<<"Stack is empty.";
    }
    else
    {
        node*temp=head;
        while(temp!=NULL)
        {
            cout<<temp->data<<", ";
            temp=temp->next;
        }
        cout<<"NULL"<<endl;
    }
}

int main()
{
    stack s;
    s.push();
    s.push();
    s.push();
    s.push();
    s.display();
    s.pop();
    s.display();
    s.pop();
    s.display();
    return 0;
}