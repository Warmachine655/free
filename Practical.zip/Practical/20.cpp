/* Convert Decimal to Binary using stack */

#include <iostream>
#include <stack>
using namespace std;


void decimalTobinary(int decimal){
    
    int original = decimal;
    stack<int> stk;
    
    if(decimal == 0){
        cout << "Binary for " << decimal << ": " << '0';
        return;
    }
    
    while(decimal > 0){
        
        stk.push(decimal % 2);
        decimal = decimal / 2;
    }
    
    cout << "Binary for " << original << ": ";
    
    while(!stk.empty()){
        
        cout << stk.top();
        stk.pop();
        
    }
    
}

int main()
{
    int decimal;
    
    cout<<"\nHello World\n\n";

    cout << "Enter decimal number: ";
    cin >> decimal;
    
    decimalTobinary(decimal);

    return 0;
}