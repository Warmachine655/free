
#include <iostream>
using namespace std;
class st1
{
    public:
    int top;
   
  st1()
  {
     
      top=-1;
  }
  int sta[3];
      void push();
      void pop();
      void display();
  };
  
void st1::push()
{
    if(top==2)
    {
        cout<<"stack is overflow"<<endl;
    }
    else
    {
        int key;
        cout<<"eneter value of key to store"<<endl;
        cin>>key;
        top=top+1;
        sta[top]=key;
    }
}

void st1::pop()
{
    if(top==-1)
    {
        cout<<"stack is underflow"<<endl;
    }
    else
    {
        top=top-1;
    }
}

void st1::display()
{ 
    if(top==-1)
    {
        cout<<"stack is empty"<<endl;
    }
    else
    {
        
    for(int i=0;i<=top;i++)
    {
        cout<<sta[i]<<endl;
    }
    }

}
int main()
{
   
    
    st1 st2;
    char ch;
    do{
    int choice;
    
    cout<<"enter your choice"<<endl<<"  1.push"<<endl<<"2.pop " <<endl<<"3.display"<<endl;
    cin>>choice;
    switch(choice)
    {
        case 1: st2.push();
                   break;
        case 2: st2.pop();
                  break;
        case 3: st2.display();
                   break;
        default: cout<<"invalid case";
    }
    cout<<"do yu want to continue press y for yes";
    cin>>ch;
}while(ch=='y'||ch=='Y');
    return 0;
}