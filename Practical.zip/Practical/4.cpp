//Write a Program to Implement queue operations using array 	

#include<iostream>
using namespace std;

class Queue{
private:
    int front;
    int rear;
    int *arr;
    int MaxSize;

public:
    Queue(int size){
        MaxSize = size;
        arr = new int[MaxSize];
        front = -1;
        rear = -1;
    }
    ~Queue(){
        delete[]arr;
    }

    //isfull, isempty, enqueue, dequeue, peek

    bool isfull(){
        return rear == MaxSize-1;
    }

    bool isempty(){
        return front == -1;
    }

    void enqueue(int data){
        if(isfull()){
            cout<<"Queue is full\n";
        }
        else{
            if(isempty()){
                front = 0;
            }
            arr[++rear] = data;
            cout<<data<<" enqued\n";
        }
    }

    int dequeue(){
        if(isempty()){
            cout<<"Queue is empty\n";
            return -1;
        }
        else{
            int dequeuedData = arr[front];
            if(front == rear){
                front = rear = -1;
            }
            else{
                front++;
            }
            cout<<dequeuedData<<" has been removed\n";
            return dequeuedData;
        }
    }

    int peek(){
        if(isempty()){
            cout<<"Queue is empty\n";
            return -1;
        }
        else{
            cout<<arr[front]<<" is next data to be removed\n";
            return arr[front];
        }
    }

    void display(){
        if(isempty()){
            cout<<"Queue is empty\n";
        }
        else{
            cout<<"Elements in queue are\n";
            for(int i = front ; i<=rear ; i++){
                cout<<arr[i]<<" -> ";
            }
            cout<<"Null\n";
        }
    }
};

int main(){
    Queue q(5);

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.dequeue();
    q.peek();
    q.dequeue();
    q.dequeue();
    q.dequeue(); // Should display "Queue is empty"
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();

    return 0;
}