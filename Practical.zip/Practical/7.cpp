//Create Binary Tree and perform operations 1. Insert 2. Display 3. Display Leaf Nodes
#include<iostream>
using namespace std;

struct Node{
    int data;
    Node*left;
    Node*right;
    Node(int val){
        data = val;
        left = nullptr;
        right = nullptr;
    }
};

class binaryTree{
private:
    Node*root;
    Node*insert(Node*node , int data){
        if(node == nullptr){
            return new Node(data);
        }
        if(data < node->data){
            node->left = insert(node->left , data);
        }
        else{
            node->right = insert(node->right , data);
        }
        return node;
    }

    void inorder(Node*node){
        if(node != nullptr){
            inorder(node->left);
            cout<<node->data<<" ";
            inorder(node->right);
        }
    }

    void displayLeafNodes(Node*node){
        if(node != nullptr){
            if(node->left == nullptr && node->right == nullptr){
                cout<<node->data<<" ";
            }
            displayLeafNodes(node->left);
            displayLeafNodes(node->right);
        }
    }

public:
    binaryTree(){
        root = nullptr;
    }

    void insert(int data){
        root = insert(root , data);
    }

    void display(){
        if(root == nullptr){
            cout<<"Tree is empty\n";
            return ;
        }
        cout<<"Inorder traversal: ";
        inorder(root);
        cout<<endl;
    }

    void displayLeafNodes(){
        if(root == nullptr){
            cout<<"Tree is empty\n";
            return ;
        }
        cout<<"leaf nodes are: ";
        displayLeafNodes(root);
        cout<<" "<<endl;
    }
};

int main(){
    binaryTree bt;
    int choice , data;

    do{
        cout << "\n1. Insert\n2. Display\n3. Display Leaf Nodes\n4. Exit\nEnter your choice: ";
        cin >> choice;
        switch (choice){
            case 1:
                cout<<"Enter a data: ";
                cin>>data;
                cout<<endl;
                bt.insert(data);
                break;
            case 2:
                bt.display();
                break;
            case 3:
                bt.displayLeafNodes();
                break;
            case 4:
                cout<<"Exitig the program";
                break;
            default:
                cout<<"Enter valid choice(1-4)";
        }
    }
    while(choice !=4);
    return 0;
}