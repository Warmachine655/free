
#include <iostream>
using namespace std;
class node
{
    public:
    int data;
    node*left;
    node*right;
    node(int data1)
    {
        data=data1;
        left=right=NULL;
    }
};

void preorder(node*temp)
{
    if(temp==NULL)
    return;
    cout<<temp->data<<" ";
    preorder(temp->left);
    preorder(temp->right);
    
}

void inorder(node*temp)
{
    if(temp==NULL)
    return;
    inorder(temp->left);
    cout<<temp->data<<" ";
    inorder(temp->right);
}

void postorder(node*temp)
{
    if(temp==NULL)
    return;
    postorder(temp->left);
    postorder(temp->right);
    cout<<temp->data<<" ";
}

int main()
{
    node*root=new node(33);
    root->left=new node(49);
    root->right=new node(87);
    root->left->left=new node(6);
    root->left->left->right=new node(8);
    root->right->left=new node(43);
    root->right->left->right=new node(7);
    root->right->right=new node(45);
    preorder(root);
    cout<<"preorder"<<endl;
    inorder(root);
    cout<<"inorder"<<endl;
    postorder(root);
    cout<<"postorder"<<endl;
    return 0;
}